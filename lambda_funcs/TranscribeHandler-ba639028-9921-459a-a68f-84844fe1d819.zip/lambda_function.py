import json
import boto3
import uuid
import time
import base64
import urllib.request

s3 = boto3.client('s3')
transcribe = boto3.client('transcribe')

BUCKET_NAME = "genairetail-database"

def lambda_handler(event, context):
    try:
        # Parse JSON body from frontend
        if not event.get('body'):
            raise ValueError("No body in request")
        body = json.loads(event['body'])

        audio_base64 = body.get('audio')
        if not audio_base64:
            raise ValueError("No audio data found in request")

        content_type = body.get('mimeType')
        language = body.get('language')

        # Determine file extension from mimetype
        if 'webm' in content_type:
            file_extension = 'webm'
        elif 'mp4' in content_type:
            file_extension = 'mp4'
        elif 'wav' in content_type:
            file_extension = 'wav'
        elif 'mpeg' in content_type or 'mp3' in content_type:
            file_extension = 'mp3'
        else:
            file_extension = 'webm'

        file_key = f"audio-{uuid.uuid4()}.{file_extension}"
        audio_bytes = base64.b64decode(audio_base64)

        # Upload result to S3
        s3.put_object(
            Bucket = BUCKET_NAME,
            Key = file_key,
            Body = audio_bytes,
            ContentType = content_type
        )

        media_uri = f"s3://{BUCKET_NAME}/{file_key}"
        job_name = f"job-{uuid.uuid4()}"

        # Start transcription
        transcribe.start_transcription_job(
            TranscriptionJobName = job_name,
            LanguageCode = language, #'en-US',
            MediaFormat = file_extension,
            Media = {'MediaFileUri': media_uri},
        )

        # Wait for transcription to finish
        for _ in range(30):
            status = transcribe.get_transcription_job(TranscriptionJobName=job_name)
            job_status = status['TranscriptionJob']['TranscriptionJobStatus']

            if job_status == 'COMPLETED':
                break
            elif job_status == 'FAILED':
                raise Exception("Transcription failed")

            time.sleep(2)
        else:
            raise Exception("Transcription timed out")

        # Get transcript
        transcript_url = status['TranscriptionJob']['Transcript']['TranscriptFileUri']

        with urllib.request.urlopen(transcript_url) as response:
            data = json.loads(response.read())

        text = data['results']['transcripts'][0]['transcript']  

        return {
            "statusCode": 200,
            "headers": {
                "Content-Type": "application/json",
                "Access-Control-Allow-Origin": "*" 
            },
            "body": json.dumps({ "text": text })
        }

    except Exception as e:
        print("Error:", str(e))
        return {
            "statusCode": 500,
            "headers": {
                "Access-Control-Allow-Origin": "*"
            },
            "body": json.dumps({ "error": "Transcription failed" })
        }