# Filename: lambda_function.py
# Author: Gen AI Retail 
# Description:
#    This program handles lambda function based on lex intents from the AI chatbot
#    It does the respective action for each lex intent connected to lambda function


import json
import boto3
import csv
import io
import difflib
from decimal import Decimal
import subprocess
import sys
#subprocess.call([sys.executable, "-m", "pip", "install", "rapidfuzz", "-t", "/tmp/"])
#sys.path.insert(0, "/tmp/")

#from rapidfuzz import process, fuzz 

s3=boto3.client('s3')
BUCKET = 'genairetail'
dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table('Cart')

region = 'us-east-1'
bedrock = boto3.client('bedrock-runtime', region_name=region)
bedrock_agent = boto3.client('bedrock-agent-runtime', region_name=region)
bedrock_runtime = boto3.client("bedrock-runtime")
CLAUDE_MODEL = 'us.anthropic.claude-sonnet-4-20250514-v1:0'
KNOWLEDGE_BASE_ID = 'WUVDCP6TBD'
translate = boto3.client("translate", region_name="us-east-1")

# Handler function parses intent for respective actions
def lambda_handler(event, context):
    print("=== NEW LEX REQUEST ===")
    print("RAW EVENT:", json.dumps(event))
    print("INTENT:", event['sessionState']['intent']['name'])
    print("INPUT:", event.get('inputTranscript'))
    intent_name = event['sessionState']['intent']['name']
    session_attrs = event['sessionState'].get('sessionAttributes', {})

    if session_attrs.get('pendingItem'):
        return addToCart(event)


    if intent_name == 'addToCart':
        return addToCart(event)

    if intent_name == 'removeItem':
        return removeFromCart(event)
    
    if intent_name == 'viewCart':
        return viewCart(event)

    if intent_name == 'QnA':
        return QnAClaude(event)

    if intent_name == 'QnAImage':
        return QnAImage(event)

    if intent_name == 'FallbackIntent':
        return fallback(event)
    
    
def chinese_to_int(text):
    if not text:
        return None

    text = str(text).strip()

    chinese_numbers = {
        "一": 1, "二": 2, "两": 2, "三": 3, "四": 4,
        "五": 5, "六": 6, "七": 7, "八": 8, "九": 9
    }

    if text in chinese_numbers:
        return chinese_numbers[text]

    if text == "十":
        return 10

    if "十" in text:
        parts = text.split("十")

        tens = chinese_numbers.get(parts[0], 1) if parts[0] else 1
        ones = chinese_numbers.get(parts[1], 0) if len(parts) > 1 else 0

        return tens * 10 + ones

    return None


def parse_quantity(raw_quantity):
    quantity = chinese_to_int(raw_quantity)

    if quantity is None:
        quantity = int(raw_quantity)

    return quantity
    
# add to cart intent function, adds users requested item to cart
def addToCart(event):
    session_attrs = event['sessionState'].get('sessionAttributes', {})
    pending_item = session_attrs.get('pendingItem')
    user_input = event.get('inputTranscript', '')

    if not pending_item :

        slots = event['sessionState']['intent']['slots']
        item_name = slots['ProductName']['value']['interpretedValue']
        raw_quantity = slots.get('Number', {}).get('value', {}).get('interpretedValue')
        quantity = parse_quantity(raw_quantity)

        raw_session_id = event['sessionId']
        if '-' in raw_session_id:
            session_id = raw_session_id.rsplit('-', 1)[0]
        else:
            session_id = raw_session_id

        item = get_item_from_s3(item_name)

        if not item:
            return lex_response(event, f"很抱歉，我们在数据库中找不到{item_name}")

        session_attrs['pendingItem'] = json.dumps(item)
        session_attrs['pendingQuantity'] = str(quantity)

        return lex_response_with_attrs(event, f"我找到了价格为${item['price']}的{item['chineseName']}。这就是你想要的吗？", session_attrs)


    else:
        print(f"In else block, user_input: '{user_input}'")
        print(f"pending_item: '{pending_item}'")


        item = json.loads(session_attrs.get('pendingItem'))
        quantity = int(session_attrs.get('pendingQuantity', 1))
        raw_session_id = event['sessionId']
        if '-' in raw_session_id:
            session_id = raw_session_id.rsplit('-', 1)[0]
        else:
            session_id = raw_session_id
        
        system_prompt = f"""
            判断用户的回复是否为'是'或'否'；如果用户表示'是'，仅回复'yes'；如果用户表示'否'，仅回复'no'。
        """

        body = {
            "anthropic_version": "bedrock-2023-05-31",
            "max_tokens": 800,
            "temperature": 0.2,
            "system": system_prompt,
            "messages": [
                {"role": "user", "content": f"{user_input}"}
            ]
        }

        response = bedrock.invoke_model(
           modelId=CLAUDE_MODEL,
            body=json.dumps(body)
        )

        result = json.loads(response["body"].read())
        answer = result["content"][0]["text"]

        print(f"Yes/no answer: '{answer}'")



        if answer == 'yes':

            quantity_prompt = f"""
            你是一个数字提取系统。

            仅返回一个整数。

            规则：
            - 仅输出数字，例如：1, 2, 3, 10
            - 禁止任何解释
            - 禁止任何句子
            - 禁止中文文本
            - 禁止任何标点符号

            示例：
            "三个苹果" -> 3
            "我要两个" -> 2
            "好的" -> 1

            用户消息：
            {user_input}
            """

            body = {
                "anthropic_version": "bedrock-2023-05-31",
                "max_tokens": 800,
                "temperature": 0.2,
                "messages": [
                    {"role": "user", "content": f"{quantity_prompt}"}
                ]
            }
            quanity_response = bedrock.invoke_model(
                modelId=CLAUDE_MODEL,
                body=json.dumps(body)
            )

            quantity_result = json.loads(quanity_response["body"].read())
            requested_quantity = quantity_result["content"][0]["text"].strip()

            print(f"Quantity extraction input: '{user_input}'")
            print(f"Bot Response: '{quantity_result}'")
            print(f"Requested quantity: '{requested_quantity}'")

            if int(requested_quantity) > 1:
                try:
                    quantity = int(requested_quantity)
                except:
                    quantity = int(session_attrs.get('pendingQuantity', 1))

            cart = get_cart(session_id)

            item_exists = False

            for cart_item in cart['items']:
                if cart_item['item']['name'] == item['name']:
                    cart_item['quantity'] += quantity
                    item_exists = True
                break

            if not item_exists:

                cart['items'].append({
                    'item': {
                        'name': item['name'], 
                        'price': Decimal(str(item['price'])),
                        'image_url': item['image_url']
                    }, 
                    'quantity': quantity
                })

            save_cart(session_id, cart)
            
            session_attrs.pop('pendingItem')
            session_attrs.pop('pendingQuantity')
    
            return lex_response_with_attrs(event, f"已将{item['chineseName']}x{quantity}加入您的购物车！", session_attrs)
        
        elif answer == 'no':
            new_item_prompt = f"""
                如果用户在此消息中请求的是另一种产品，或者正在细化其搜索条件，请从消息中提取相关内容：'{user_input}'。 
                如果用户**确实**是在更新搜索条件，请**仅**返回描述其所需商品的文本片段；若用户指定了具体名称，则返回该商品的名称。 
                示例：
                “不，我要的是单根香蕉” -> “单根香蕉”
                “不，我要的是2%脱脂奶” -> “2%脱脂奶”
                “不对，我要的是有机苹果” -> “有机苹果”

                如果用户**并非**在更新搜索条件，且其消息的含义仅为“不，这不是我想要的”，请直接返回‘No’
            """

            body = {
                "anthropic_version": "bedrock-2023-05-31",
                "max_tokens": 800,
                "temperature": 0.2,
                "messages": [
                    {"role": "user", "content": f"{new_item_prompt}"}
                ]
            }
            new_item_response = bedrock.invoke_model(
                modelId=CLAUDE_MODEL,
                body=json.dumps(body)
            )

            new_item_response = json.loads(new_item_response["body"].read())
            new_item_text = new_item_response["content"][0]["text"]
            print(f"new item: {new_item_text}")


            if new_item_text == 'No':
                session_attrs.pop('pendingItem')
                session_attrs.pop('pendingQuantity')
                return lex_response_with_attrs(event, f"很抱歉，我没有找到合适的产品。您能试着用另一种方式描述一下吗？", session_attrs)
            
            else:
                
                session_attrs.pop('pendingItem')
                session_attrs.pop('pendingQuantity')

                new_item = get_item_from_s3(new_item_text)

                if not new_item:
                    return lex_response(event, f"很抱歉，未能在我们的数据库中找到 {new_item_name}")

                session_attrs['pendingItem'] = json.dumps(new_item)
                session_attrs['pendingQuantity'] = str(quantity)

                return lex_response_with_attrs(event, f"好的！我找到了 {new_item['chineseName']}，价格是 ${new_item['price']}。这是您想要的吗？",session_attrs)

                #event["sessionState"]["sessionAttributes"] = session_attrs
                #event["sessionState"]["intent"]["slots"]["ProductName"]["value"]["interpretedValue"] = new_item_text
                #return addToCart(event)

def int_to_chinese(num):
    chinese_digits = {
        1: "一", 2: "两", 3: "三", 4: "四",
        5: "五", 6: "六", 7: "七", 8: "八", 9: "九"
    }

    if num < 10:
        return chinese_digits[num]

    if num == 10:
        return "十"

    return ""

# remove items from cart
def removeFromCart(event):
    raw_session_id = event['sessionId']
    if '-' in raw_session_id:
        session_id = raw_session_id.rsplit('-', 1)[0]
    else:
        session_id = raw_session_id
    cart = get_cart(session_id)

    session_attrs = event['sessionState'].get('sessionAttributes', {})
    user_input = event.get('inputTranscript', '')

    if not cart['items']:
        return lex_response(event, f"您的购物车是空的")

    prompt = f"""根据 {cart} 中的商品列表，仅返回用户最有可能想要移除的那件商品的“确切名称”。 
                 如果用户的查询表明他们想要彻底清空购物车，则仅返回'all'。
                 以下是用户的查询：{user_input}
    """
    body = {
                "anthropic_version": "bedrock-2023-05-31",
                "max_tokens": 800,
                "temperature": 0.2,
                "messages": [
                    {"role": "user", "content": f"{prompt}"}
                ]
            }
    item_response = bedrock.invoke_model(
        modelId=CLAUDE_MODEL,
        body=json.dumps(body)
    )

    item_result = json.loads(item_response["body"].read())
    item_request = item_result["content"][0]["text"]

    prompt_num = f"""根据此消息："{user_input}"
                     仅返回以下两项内容之一：
                     - 如果提到了具体的数字，则返回该整数。示例：“remove 2 milk” -> 2
                     - 如果未提及数字，则返回单词'max'。示例：“remove the milk” -> max

                     请勿进行解释。请勿添加标点符号。仅返回整数或单词'max'。"""

    body = {
                "anthropic_version": "bedrock-2023-05-31",
                "max_tokens": 800,
                "temperature": 0.2,
                "messages": [
                    {"role": "user", "content": f"{prompt_num}"}
                ]
            }
    num_response = bedrock.invoke_model(
        modelId=CLAUDE_MODEL,
        body=json.dumps(body)
    )

    num_result = json.loads(num_response["body"].read())
    num_request= num_result["content"][0]["text"]

    if item_request == 'all':
        empty_cart = {'session_id': session_id, 'items': []}
        save_cart(session_id, empty_cart)
        return lex_response_with_attrs(event, "您的购物车已清空！", session_attrs)

    if num_request == 'max':
        for i in cart['items']:
            if i['item']['name'] == item_request:
                cart['items'].remove(i)
                break

        save_cart(session_id, cart)
        chinese_name = get_chinese_name(item_request)
        return lex_response_with_attrs(event, f"已将{chinese_name['name']}从您的购物车中清除！", session_attrs)

    else:
        for i in cart['items']:
            if i['item']['name'] == item_request:
                i['quantity'] -= int(num_request)
                if i['quantity'] <= 0:
                    cart['items'].remove(i)
                break
        
        save_cart(session_id, cart)
        chinese_num = int_to_chinese(int(num_request))
        chinese_name = get_chinese_name(item_request)
        return lex_response_with_attrs(event, f"已从您的购物车中清除{chinese_num}个{chinese_name['name']}！", session_attrs)


def get_chinese_name(item_name):
    try: 
        response = s3.get_object(Bucket=BUCKET, Key='chinese_DB.csv')
        content = response['Body'].read().decode('utf-8')
        reader = csv.DictReader(io.StringIO(content))
        rows = list(reader)

        #bestMatch = findBestMatch(item_name, rows)
        bestMatch = searchKnowledgeBase(item_name)
        if not bestMatch:
            return None

        for row in rows:
            if row['product_name'] == bestMatch:
                return{
                    'name': row['产品_名称']
                }
        return None
    
    except Exception as e:
        print(f"Error fetching item from S3: {e}")
        return None
    

# view to cart intent function, prints out the users cart
def viewCart(event):
    raw_session_id = event['sessionId']
    if '-' in raw_session_id:
        session_id = raw_session_id.rsplit('-', 1)[0]
    else:
        session_id = raw_session_id
    cart = get_cart(session_id)
    total = 0
    if not cart['items']:
        return lex_response(event, f"您的购物车是空的")

    cart_list_parts = []

    for i in cart['items']:
        item_name_cn = translate_text(i['item']['name'], "zh")
        cart_list_parts.append(f"{item_name_cn}×{i['quantity']}")

        total += i['quantity'] * i['item']['price']

    cart_list = "，".join(cart_list_parts)

    return lex_response(event, f"这是您的购物车: {cart_list} 总价格: {total:.2f}")

    # format i want
    # Here is your cart:
    # x2 Bananas
    # x3 oranges
    # x1 Whole Milk
    # Total: $10.25

# get items from s3, searches for s3 items and returns data about specific item
def get_item_from_s3(item_name):
    try: 
        response = s3.get_object(Bucket=BUCKET, Key='chinese_DB.csv')
        content = response['Body'].read().decode('utf-8')
        reader = csv.DictReader(io.StringIO(content))
        rows = list(reader)

        #bestMatch = findBestMatch(item_name, rows)
        bestMatch = searchKnowledgeBase(item_name)
        if not bestMatch:
            return None

        for row in rows:
            if row['产品_名称'] == bestMatch:
                return{
                    'name': row['product_name'],
                    'chineseName': row['产品_名称'],
                    'price': float(row['价格']) if row['价格'] else None,
                    'image_url': row['图像_url'] if row['图像_url'] else None,
                    ##'quantity': int(row['quantity']) if row['quantity'] else None,
                }
        return None
    
    except Exception as e:
        print(f"Error fetching item from S3: {e}")
        return None

# OLDEST find best match, string matches best match from  csv database
def findBestMatch_old(item_name, rows):  ## keeping this function for future functions like remove from cart
    names = [row['product_name'] for row in rows]
    matches = difflib.get_close_matches(item_name, names, n=1, cutoff = 0.6)
    return matches[0] if matches else None

# OLD find best match, finds best match from csv database based on user search items
def findBestMatch(item_name, rows):
    names = [row['product_name'] for row in rows]
   
    results = process.extract(item_name, names, scorer=fuzz.token_sort_ratio, limit = 3)
    print(results)

    if not results:
        return None

    best_match, score, index = results[0]  

    if score < 0:  
        return None

    return best_match

# search bedrock knowledge base, new 'find best match'
def searchKnowledgeBase(item_name):
    lookup = bedrock_agent.retrieve(
        knowledgeBaseId=KNOWLEDGE_BASE_ID,
        retrievalQuery={
            'text': item_name
        },
        retrievalConfiguration={
            'vectorSearchConfiguration': {
                'numberOfResults': 10
            }
        }
    )

    returned_item = "\n".join([r['content']['text'] for r in lookup['retrievalResults']]) if lookup['retrievalResults'] else ' '

    
    system_prompt = f"""
        您是一位产品匹配助手。
        请协助将商品名称：{item_name} 与提供的知识库搜索结果：{returned_item} 中最匹配的产品名称进行对应。

        请找出与顾客搜索内容“最”吻合的产品名称。
        顾客在描述产品时，可能并非直接使用其确切名称。
        示例：
            - “单独的橙子” -> “橙子”
            - “搭配早餐麦片的食物” -> “燕麦片” 或 “格兰诺拉麦片”
        请“仅”返回文本中显示的确切产品名称，不得包含其他内容。
        请勿返回配料信息，亦勿返回部分匹配的结果。
    """

    body = {
        "anthropic_version": "bedrock-2023-05-31",
        "max_tokens": 800,
        "temperature": 0.2,
        "system": system_prompt,
        "messages": [
            {"role": "user", "content": f"查找最佳匹配项: {item_name}"}
        ]
    }

    response = bedrock.invoke_model(
        modelId=CLAUDE_MODEL,
        body=json.dumps(body)
    )

    result = json.loads(response["body"].read())
    answer = result["content"][0]["text"]

    #print(f"KB returned text: '{returned_item}'")
    #print(f"KB Search for '{item_name}' returned: '{answer}'")
    
    return answer

# get cart, gets cart from dynamoDB table
def get_cart(session_id):
    try:
        response = table.get_item(Key={'session_id' : session_id})
        return response.get('Item', {'session_id': session_id, 'items' : []})
    except Exception as e:
        print(f"Error fetching cart: {e}")
        return {'session_id': session_id, 'items': []}
    
# save cart, adds item to cart and saves it
def save_cart(session_id, cart):
    try:
        table.put_item(Item=cart)
    except Exception as e:
        print(f"Error saving cart: {e}")

# QnA,  queries claude about user question
def QnAClaude(event):
    session_attrs = event['sessionState'].get('sessionAttributes', {})
    if session_attrs.get('pendingItem'):
        return addToCart(event)

    user_input = event.get('inputTranscript', '')
    
    slots = event['sessionState']['intent'].get('slots', {})
    item = None

    if slots and slots.get('Item'):
        item = slots['Item']['value']['interpretedValue']

    query = item if item else user_input

    try:
        kb_response = bedrock_agent.retrieve(
            knowledgeBaseId = KNOWLEDGE_BASE_ID,
            retrievalQuery={
                "text": query
            }
        )

        results = kb_response.get("retrievalResults", [])

        context = "\n\n".join([
            r["content"]["text"] for r in results if "content" in r
        ])

        prompt = f"""
            您是一位乐于助人的生鲜购物助手。请依据下方语境回答问题。请勿提及生鲜数据库中未收录的商品。

        内容:
        {context}

        问题:
        {query}

        请以清晰、简洁的方式作答:
        """

        response = bedrock_runtime.invoke_model(
            modelId = CLAUDE_MODEL,
            contentType = "application/json",
            accept = "application/json",
            body = json.dumps({
                "anthropic_version": "bedrock-2023-05-31",
                "max_tokens": 500,
                "messages": [
                    {
                        "role": "user",
                        "content": prompt
                    }
                ]
            })
        )

        result_body = json.loads(response["body"].read())
        answer = result_body["content"][0]["text"]

    except Exception as e:
        print("Bedrock KB error:", str(e))
        answer = "不好意思，暂时无法获取信息"

    return lex_response(event, answer)

# get items from s3, searches for s3 image url and returns the image url about specific item
def get_imageurl_from_s3(item_name):
    try: 
        response = s3.get_object(Bucket=BUCKET, Key='chinese_DB.csv')
        content = response['Body'].read().decode('utf-8')
        reader = csv.DictReader(io.StringIO(content))
        rows = list(reader)

        #bestMatch = findBestMatch(item_name, rows)
        bestMatch = searchKnowledgeBase(item_name)
        if not bestMatch:
            return None

        for row in rows:
            if row['产品_名称'] == bestMatch:
                return{
                    'name': row['产品_名称'],
                    'image_url': row['图像_url'] if row['图像_url'] else None,
                }
        return None
    
    except Exception as e:
        print(f"Error fetching item from S3: {e}")
        return None

# Find image url of product and return the product name and image url
def QnAImage(event):
    session_attrs = event['sessionState'].get('sessionAttributes', {})
    if session_attrs.get('pendingItem'):
        return addToCart(event)

    slots = event['sessionState']['intent']['slots']
    item_name = slots['Product']['value']['interpretedValue']

    item = get_imageurl_from_s3(item_name)

    if item and item.get('image_url'):
        message = f"这是一张{item['name']}的图片: {item['image_url']}"
    else:
        message = f"抱歉，我没有{item_name}的图片."

    return lex_response(event, message)

def fallback(event):
    raw_session_id = event['sessionId']
    if '-' in raw_session_id:
        session_id = raw_session_id.rsplit('-', 1)[0]
    else:
        session_id = raw_session_id
    session_attrs = event['sessionState'].get('sessionAttributes', {})
    cart = get_cart(session_id)
    message = event.get('inputTranscript', '')
    session_attrs = event['sessionState'].get('sessionAttributes', {})
    history = json.loads(session_attrs.get('conversationHistory', '[]'))
    cart_contents = ", ".join([i['item']['name'] for i in cart['items']]) if cart['items'] else "empty"


    system_prompt = f"""You are a friendly grocery shopping assistant. 
    Current cart: {cart_contents}
    Be conversational and keep responses concise. Dont mention products that are not in the grocery database"""

    body = {
        "anthropic_version": "bedrock-2023-05-31",
        "max_tokens": 800,
        "temperature": 0.2,
        "system": system_prompt,
        "messages":  history + [{ "role": "user", "content": message }]
        }

    
    response = bedrock.invoke_model(
        modelId=CLAUDE_MODEL,
        body=json.dumps(body)
    )

    result = json.loads(response["body"].read())
    answer = result["content"][0]["text"]
    history.append({'role': 'user', 'content': message})
    history.append({'role': 'assistant', 'content': answer})
    session_attrs['conversationHistory'] = json.dumps(history)


    return lex_response_with_attrs(event, answer, session_attrs)

translation_cache = {}

def translate_text(text, target_lang="zh"):
    if not text:
        return text

    key = (text, target_lang)

    if key in translation_cache:
        return translation_cache[key]

    response = translate.translate_text(
        Text=text,
        SourceLanguageCode="auto",
        TargetLanguageCode=target_lang
    )

    result = response["TranslatedText"]
    translation_cache[key] = result

    return result
    
# lex response, formating for lex to give a response to user
def lex_response(event, message):
    return {
        "sessionState": {
            "dialogAction": {"type": "Close"},
            "intent": {
                "name": event['sessionState']['intent']['name'],
                "state": "Fulfilled"
            }
        },
        "messages": [{"contentType": "PlainText", "content": message}]
    }


def lex_response_with_attrs(event, message, session_attrs):
    return {
        "sessionState": {
            "dialogAction": {"type": "Close"},
            "intent": {
                "name": event['sessionState']['intent']['name'],
                "state": "Fulfilled"
            },
            "sessionAttributes": session_attrs
        },
        "messages": [{"contentType": "PlainText", "content": message}]
    }