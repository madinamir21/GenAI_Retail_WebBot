import { DynamoDBClient, UpdateItemCommand } from "@aws-sdk/client-dynamodb";
import { DynamoDBDocumentClient, PutCommand } from "@aws-sdk/lib-dynamodb";

const client = new DynamoDBClient({});
const docClient = DynamoDBDocumentClient.from(client);

export const handler = async (event) => {    

    const headers = {
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Headers": "Content-Type",
      "Access-Control-Allow-Methods": "OPTIONS, POST",
      "Content-Type": "application/json"
    };

  try{

    // Send order data to Orders DynamoDB table
    //const body = JSON.parse(event.body);

    /* if (!event.body) {
      return {
        statusCode: 400,
        body: JSON.stringify({ error: "Empty request body" })
      };
    } */

  /*   let rawBody = event.body;
    if (event.isBase64Encoded) {
        rawBody = Buffer.from(event.body, 'base64').toString('utf8');
    }
    const body = typeof rawBody === 'string' ? JSON.parse(rawBody) : rawBody;
    
    const item = {
      orderId: crypto.randomUUID(),
      createdAt: new Date().toISOString(),
      //sessionId: body.id,
      //shipping: body.shipping,
      //billing: body.billing,
      //payment: body.payment,
      //cartItems: body.cartItems
    }; */

    /* await docClient.send(new PutCommand({
      TableName: "Orders",
      Item: item,
    }));

    // Clear user's cart based on the user id
    await client.send(new UpdateItemCommand({
      TableName: "Cart",
      Key: {
        session_id: { S: body.id }
      },
      UpdateExpression: "SET orders = :empty",
      ExpressionAttributeValues: {
        ":empty": { L: [] }
      }
    })); */

    return {
      statusCode: 200,
      headers: headers,
      body: JSON.stringify({ message: "Order stored" }),
    };
    
  } catch(error) {
    return {
      statusCode: 500,
      headers: headers,
      body: JSON.stringify({ error: "Error: ", error }),
    };
  }

};