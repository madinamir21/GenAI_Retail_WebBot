import json
import boto3
import csv
import io
from decimal import Decimal

s3 = boto3.client('s3')
BUCKET = 'genairetail'
dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table('Cart')

region = 'us-east-1'
bedrock = boto3.client('bedrock-runtime', region_name=region)
bedrock_agent = boto3.client('bedrock-agent-runtime', region_name=region)
bedrock_runtime = boto3.client("bedrock-runtime")
CLAUDE_MODEL = 'us.anthropic.claude-sonnet-4-20250514-v1:0'
KNOWLEDGE_BASE_ID = 'CXDJPPGFXR'
SPANISH_DB = 'spanish_DB.csv'
translate = boto3.client("translate", region_name="us-east-1")

def lambda_handler(event, context):
    print("=== NEW LEX REQUEST ===")
    print("RAW EVENT:", json.dumps(event))
    print("INTENT:", event['sessionState']['intent']['name'])
    print("INPUT:", event.get('inputTranscript'))

    intent_name = event['sessionState']['intent']['name']
    session_attrs = event['sessionState'].get('sessionAttributes', {})

    if session_attrs.get('pendingItem'):
        return addToCart(event)

    if intent_name == 'addToCart':
        return addToCart(event)
    if intent_name == 'removeItem':
        return removeFromCart(event)
    if intent_name == 'viewCart':
        return viewCart(event)
    if intent_name == 'QnA':
        return QnAClaude(event)
    if intent_name == 'QnAIngredient':
        return QnAIngredient(event)
    if intent_name == 'QnAImage':
        return QnAImage(event)
    if intent_name == 'WelcomeIntent':
        return lex_response(event, "¡Hola! Bienvenido a tu asistente de compras. ¿En qué puedo ayudarte hoy?")
    if intent_name == 'FallbackIntent':
        return fallback(event)

def addToCart(event):
    session_attrs = event['sessionState'].get('sessionAttributes', {})
    pending_item = session_attrs.get('pendingItem')
    user_input = event.get('inputTranscript', '')

    if not pending_item:
        slots = event['sessionState']['intent']['slots']
        # item_name = slots['ProductName']['value']['interpretedValue']
        product_slot = slots.get('ProductName')

        if not product_slot or not product_slot.get('value'):
            return lex_response(event, "¿Qué producto deseas agregar a tu carrito?")

        item_name = product_slot['value']['interpretedValue']
        quantity = int(slots.get('Number', {}).get('value', {}).get('interpretedValue', 1))

        raw_session_id = event['sessionId']
        session_id = raw_session_id.rsplit('-', 1)[0] if '-' in raw_session_id else raw_session_id

        item = get_item_from_s3(item_name)

        if not item:
            return lex_response(event, f"Lo siento, no pude encontrar {item_name} en nuestra base de datos.")

        session_attrs['pendingItem'] = json.dumps(item)
        session_attrs['pendingQuantity'] = str(quantity)
        return lex_response_with_attrs(event, f"Encontré {item['name']} por ${item['price']}. ¿Es eso lo que querías?", session_attrs)

    else:
        print(f"In else block, user_input: '{user_input}'")
        print(f"pending_item: '{pending_item}'")

        item = json.loads(session_attrs.get('pendingItem'))
        quantity = int(session_attrs.get('pendingQuantity', 1))
        raw_session_id = event['sessionId']
        session_id = raw_session_id.rsplit('-', 1)[0] if '-' in raw_session_id else raw_session_id

        system_prompt = "Deduce si la respuesta del usuario es sí o no. Responde solo con 'yes' si dice que sí, y 'no' si dice que no."

        body = {
            "anthropic_version": "bedrock-2023-05-31",
            "max_tokens": 100,
            "temperature": 0.2,
            "system": system_prompt,
            "messages": [{"role": "user", "content": user_input}]
        }

        response = bedrock.invoke_model(modelId=CLAUDE_MODEL, body=json.dumps(body))
        result = json.loads(response["body"].read())
        answer = result["content"][0]["text"]
        print(f"Yes/no answer: '{answer}'")

        if answer == 'yes':
            quantity_prompt = f"Si el usuario pidió una cantidad específica en este mensaje: '{user_input}', devuelve SOLO el número entero. Si no se menciona ninguno, devuelve 1."

            body = {
                "anthropic_version": "bedrock-2023-05-31",
                "max_tokens": 100,
                "temperature": 0.2,
                "messages": [{"role": "user", "content": quantity_prompt}]
            }
            quantity_response = bedrock.invoke_model(modelId=CLAUDE_MODEL, body=json.dumps(body))
            quantity_result = json.loads(quantity_response["body"].read())
            requested_quantity = quantity_result["content"][0]["text"].strip()
            print(f"Requested quantity: '{requested_quantity}'")

            if int(requested_quantity) > 1:
                try:
                    quantity = int(requested_quantity)
                except:
                    quantity = int(session_attrs.get('pendingQuantity', 1))

            cart = get_cart(session_id)
            cart['items'].append({
                'item': {
                    'name': item['name'],
                    'price': Decimal(str(item['price'])),
                    'image_url': item['image_url']
                },
                'quantity': quantity
            })
            save_cart(session_id, cart)

            session_attrs.pop('pendingItem')
            session_attrs.pop('pendingQuantity')
            return lex_response_with_attrs(event, f"¡Agregué {quantity}x {item['name']} a tu carrito!", session_attrs)

        elif answer == 'no':
            new_item_prompt = f"""
                Deduce si el usuario está pidiendo un producto diferente: '{user_input}'.
                Si SÍ está cambiando su búsqueda, devuelve SOLO la descripción del producto.
                Ejemplos:
                "No, quiero la leche descremada" -> "leche descremada"
                "No, quiero manzanas orgánicas" -> "manzanas orgánicas"
                Si NO está cambiando su búsqueda, devuelve solo "No".
            """

            body = {
                "anthropic_version": "bedrock-2023-05-31",
                "max_tokens": 200,
                "temperature": 0.2,
                "messages": [{"role": "user", "content": new_item_prompt}]
            }
            new_item_response = bedrock.invoke_model(modelId=CLAUDE_MODEL, body=json.dumps(body))
            new_item_response = json.loads(new_item_response["body"].read())
            new_item_text = new_item_response["content"][0]["text"]
            print(f"new item: {new_item_text}")

            if new_item_text == 'No':
                session_attrs.pop('pendingItem')
                session_attrs.pop('pendingQuantity')
                return lex_response_with_attrs(event, "Lo siento, no encontré el producto correcto. ¿Puedes describirlo de otra manera?", session_attrs)
            else:
                session_attrs.pop('pendingItem')
                session_attrs.pop('pendingQuantity')
                new_item = get_item_from_s3(new_item_text)
                if not new_item:
                    return lex_response(event, f"Lo siento, no pude encontrar {new_item_text} en nuestra base de datos.")
                session_attrs['pendingItem'] = json.dumps(new_item)
                session_attrs['pendingQuantity'] = str(quantity)
                return lex_response_with_attrs(event, f"¡Encontré {new_item['name']} por ${new_item['price']}. ¿Es eso lo que querías?", session_attrs)

def removeFromCart(event):
    raw_session_id = event['sessionId']
    session_id = raw_session_id.rsplit('-', 1)[0] if '-' in raw_session_id else raw_session_id
    cart = get_cart(session_id)
    session_attrs = event['sessionState'].get('sessionAttributes', {})
    user_input = event.get('inputTranscript', '')

    if not cart['items']:
        return lex_response(event, "Tu carrito está vacío.")

    prompt = f"""De la lista de artículos en {cart}, devuelve SOLO el nombre exacto del artículo que el usuario quiere eliminar.
                Si el usuario quiere vaciar su carrito completamente, devuelve SOLO 'all'.
                Esta es la consulta del usuario: {user_input}
    """
    body = {
        "anthropic_version": "bedrock-2023-05-31",
        "max_tokens": 200,
        "temperature": 0.2,
        "messages": [{"role": "user", "content": prompt}]
    }
    item_response = bedrock.invoke_model(modelId=CLAUDE_MODEL, body=json.dumps(body))
    item_result = json.loads(item_response["body"].read())
    item_request = item_result["content"][0]["text"]

    prompt_num = f"""De este mensaje: "{user_input}"
                Devuelve SOLO uno de estos dos:
                - El número entero si se menciona uno. Ejemplo: "elimina 2 leches" -> 2
                - La palabra max si no se menciona ninguno. Ejemplo: "elimina la leche" -> max
                Sin explicaciones. Solo el entero o la palabra max."""

    body = {
        "anthropic_version": "bedrock-2023-05-31",
        "max_tokens": 50,
        "temperature": 0.2,
        "messages": [{"role": "user", "content": prompt_num}]
    }
    num_response = bedrock.invoke_model(modelId=CLAUDE_MODEL, body=json.dumps(body))
    num_result = json.loads(num_response["body"].read())
    num_request = num_result["content"][0]["text"]

    if item_request == 'all':
        save_cart(session_id, {'session_id': session_id, 'items': []})
        return lex_response_with_attrs(event, "¡Tu carrito ha sido vaciado!", session_attrs)

    if num_request == 'max':
        for i in cart['items']:
            if i['item']['name'] == item_request:
                cart['items'].remove(i)
                break
        save_cart(session_id, cart)
        return lex_response_with_attrs(event, f"¡Eliminé {item_request} de tu carrito!", session_attrs)
    else:
        for i in cart['items']:
            if i['item']['name'] == item_request:
                i['quantity'] -= int(num_request)
                if i['quantity'] <= 0:
                    cart['items'].remove(i)
                break
        save_cart(session_id, cart)
        return lex_response_with_attrs(event, f"¡Eliminé {num_request}x {item_request} de tu carrito!", session_attrs)

def viewCart(event):
    raw_session_id = event['sessionId']
    session_id = raw_session_id.rsplit('-', 1)[0] if '-' in raw_session_id else raw_session_id
    cart = get_cart(session_id)
    total = 0

    if not cart['items']:
        return lex_response(event, "¡Tu carrito está vacío!")

    cart_list_parts = []
    for i in cart['items']:
        item_name_es = translate_text(i['item']['name'], "es")
        cart_list_parts.append(f"{item_name_es}×{i['quantity']}")
        total += i['quantity'] * i['item']['price']

    cart_list = ", ".join(cart_list_parts)
    return lex_response(event, f"Tu carrito: {cart_list} | Total: ${total:.2f}")

def get_item_from_s3(item_name):
    try:
        response = s3.get_object(Bucket=BUCKET, Key=SPANISH_DB)
        content = response['Body'].read().decode('utf-8')
        reader = csv.DictReader(io.StringIO(content))
        rows = list(reader)

        bestMatch = searchKnowledgeBase(item_name)
        if not bestMatch:
            return None

        for row in rows:
            if row['nombre_del_producto'] == bestMatch:
                return {
                    'name': row['nombre_del_producto'],
                    'price': float(row['precio']) if row['precio'] else None,
                    'image_url': row['url_de_la_imagen'] if row['url_de_la_imagen'] else None,
                }
        return None

    except Exception as e:
        print(f"Error fetching item from S3: {e}")
        return None

def get_imageurl_from_s3(item_name):
    try:
        response = s3.get_object(Bucket=BUCKET, Key=SPANISH_DB)
        content = response['Body'].read().decode('utf-8')
        reader = csv.DictReader(io.StringIO(content))
        rows = list(reader)

        bestMatch = searchKnowledgeBase(item_name)
        if not bestMatch:
            return None

        for row in rows:
            if row['nombre_del_producto'] == bestMatch:
                return {
                    'name': row['nombre_del_producto'],
                    'image_url': row['url_de_la_imagen'] if row['url_de_la_imagen'] else None,
                }
        return None

    except Exception as e:
        print(f"Error fetching item from S3: {e}")
        return None

def searchKnowledgeBase(item_name):
    lookup = bedrock_agent.retrieve(
        knowledgeBaseId=KNOWLEDGE_BASE_ID,
        retrievalQuery={'text': item_name},
        retrievalConfiguration={'vectorSearchConfiguration': {'numberOfResults': 10}}
    )

    returned_item = "\n".join([r['content']['text'] for r in lookup['retrievalResults']]) if lookup['retrievalResults'] else ' '

    system_prompt = f"""
        Eres un asistente de coincidencia de productos.
        Ayuda a encontrar la mejor coincidencia para el nombre del producto: {item_name}
        de los resultados de búsqueda de la base de conocimientos: {returned_item}
        Encuentra el nombre del producto que MEJOR coincida con lo que busca el cliente.
        El cliente puede describir un producto en lugar de nombrarlo exactamente.
        Ejemplos:
        - "fruta naranja sola" -> "Naranjas"
        - "algo para el cereal del desayuno" -> "Avena" o "Granola"
        Devuelve SOLO el nombre exacto del producto tal como aparece en el texto.
        No devuelvas ingredientes ni coincidencias parciales.
    """

    body = {
        "anthropic_version": "bedrock-2023-05-31",
        "max_tokens": 200,
        "temperature": 0.2,
        "system": system_prompt,
        "messages": [{"role": "user", "content": f"Encuentra la mejor coincidencia para: {item_name}"}]
    }

    response = bedrock.invoke_model(modelId=CLAUDE_MODEL, body=json.dumps(body))
    result = json.loads(response["body"].read())
    return result["content"][0]["text"]
    # DEBUG PRINT
    print(f"KB Search for '{item_name}' returned: '{returned_item[:200]}'")

def QnAClaude(event):
    session_attrs = event['sessionState'].get('sessionAttributes', {})
    if session_attrs.get('pendingItem'):
        return addToCart(event)

    user_input = event.get('inputTranscript', '')
    slots = event['sessionState']['intent'].get('slots', {})
    item = None

    if slots and slots.get('Product'):
        item = slots['Product']['value']['interpretedValue']

    query = item if item else user_input

    try:
        kb_response = bedrock_agent.retrieve(
            knowledgeBaseId=KNOWLEDGE_BASE_ID,
            retrievalQuery={"text": query}
        )

        results = kb_response.get("retrievalResults", [])
        context = "\n\n".join([r["content"]["text"] for r in results if "content" in r])

        prompt = f"""
            Eres un asistente de compras de supermercado. Responde la pregunta basándote en el contexto proporcionado.
            No menciones productos que no estén en la base de datos del supermercado.

            Contexto:
            {context}

            Pregunta:
            {query}

            Responde de forma clara y concisa en español:
        """

        response = bedrock_runtime.invoke_model(
            modelId=CLAUDE_MODEL,
            contentType="application/json",
            accept="application/json",
            body=json.dumps({
                "anthropic_version": "bedrock-2023-05-31",
                "max_tokens": 500,
                "messages": [{"role": "user", "content": prompt}]
            })
        )

        result_body = json.loads(response["body"].read())
        answer = result_body["content"][0]["text"]

    except Exception as e:
        print("Bedrock KB error:", str(e))
        answer = "Lo siento, no puedo obtener esa información ahora mismo."

    return lex_response(event, answer)

def QnAIngredient(event):
    session_attrs = event['sessionState'].get('sessionAttributes', {})
    if session_attrs.get('pendingItem'):
        return addToCart(event)

    user_input = event.get('inputTranscript', '')
    slots = event['sessionState']['intent'].get('slots', {})
    item = None

    if slots and slots.get('Product'):
        item = slots['Product']['value']['interpretedValue']

    query = item if item else user_input

    try:
        kb_response = bedrock_agent.retrieve(
            knowledgeBaseId=KNOWLEDGE_BASE_ID,
            retrievalQuery={"text": query}
        )

        results = kb_response.get("retrievalResults", [])
        context = "\n\n".join([r["content"]["text"] for r in results if "content" in r])

        prompt = f"""
            Eres un asistente de compras de supermercado. Responde la pregunta sobre ingredientes basándote en el contexto proporcionado.

            Contexto:
            {context}

            Pregunta:
            {query}

            Responde de forma clara y concisa en español:
        """

        response = bedrock_runtime.invoke_model(
            modelId=CLAUDE_MODEL,
            contentType="application/json",
            accept="application/json",
            body=json.dumps({
                "anthropic_version": "bedrock-2023-05-31",
                "max_tokens": 500,
                "messages": [{"role": "user", "content": prompt}]
            })
        )

        result_body = json.loads(response["body"].read())
        answer = result_body["content"][0]["text"]

    except Exception as e:
        print("Ingredients KB error:", str(e))
        answer = "Lo siento, no puedo obtener esa información ahora mismo."

    return lex_response(event, answer)

def QnAImage(event):
    session_attrs = event['sessionState'].get('sessionAttributes', {})
    if session_attrs.get('pendingItem'):
        return addToCart(event)

    slots = event['sessionState']['intent']['slots']
    item_name = slots['Product']['value']['interpretedValue']

    item = get_imageurl_from_s3(item_name)

    if item and item.get('image_url'):
        message = f"Aquí tienes una imagen de {item['name']}: {item['image_url']}"
    else:
        message = f"Lo siento, no tengo una imagen para {item_name}."

    return lex_response(event, message)

def fallback(event):
    raw_session_id = event['sessionId']
    session_id = raw_session_id.rsplit('-', 1)[0] if '-' in raw_session_id else raw_session_id
    session_attrs = event['sessionState'].get('sessionAttributes', {})
    cart = get_cart(session_id)
    message = event.get('inputTranscript', '')
    history = json.loads(session_attrs.get('conversationHistory', '[]'))
    cart_contents = ", ".join([i['item']['name'] for i in cart['items']]) if cart['items'] else "vacío"

    system_prompt = f"""Eres un asistente de compras de supermercado amigable.
    IMPORTANTE: Debes responder SIEMPRE en español. NUNCA respondas en inglés.
    Carrito actual: {cart_contents}
    Sé conversacional y conciso. No menciones productos que no estén en la base de datos del supermercado."""

    body = {
        "anthropic_version": "bedrock-2023-05-31",
        "max_tokens": 800,
        "temperature": 0.2,
        "system": system_prompt,
        "messages": history + [{"role": "user", "content": message}]
    }

    response = bedrock.invoke_model(modelId=CLAUDE_MODEL, body=json.dumps(body))
    result = json.loads(response["body"].read())
    answer = result["content"][0]["text"]
    history.append({'role': 'user', 'content': message})
    history.append({'role': 'assistant', 'content': answer})
    session_attrs['conversationHistory'] = json.dumps(history)

    return lex_response_with_attrs(event, answer, session_attrs)

def get_cart(session_id):
    try:
        response = table.get_item(Key={'session_id': session_id})
        return response.get('Item', {'session_id': session_id, 'items': []})
    except Exception as e:
        print(f"Error fetching cart: {e}")
        return {'session_id': session_id, 'items': []}

def save_cart(session_id, cart):
    try:
        table.put_item(Item=cart)
    except Exception as e:
        print(f"Error saving cart: {e}")

translation_cache = {}

def translate_text(text, target_lang="es"):
    if not text:
        return text

    key = (text, target_lang)

    if key in translation_cache:
        return translation_cache[key]

    response = translate.translate_text(
        Text=text,
        SourceLanguageCode="auto",
        TargetLanguageCode=target_lang
    )

    result = response["TranslatedText"]
    translation_cache[key] = result

    return result

def lex_response(event, message):
    return {
        "sessionState": {
            "dialogAction": {"type": "Close"},
            "intent": {
                "name": event['sessionState']['intent']['name'],
                "state": "Fulfilled"
            }
        },
        "messages": [{"contentType": "PlainText", "content": message}]
    }

def lex_response_with_attrs(event, message, session_attrs):
    return {
        "sessionState": {
            "dialogAction": {"type": "Close"},
            "intent": {
                "name": event['sessionState']['intent']['name'],
                "state": "Fulfilled"
            },
            "sessionAttributes": session_attrs
        },
        "messages": [{"contentType": "PlainText", "content": message}]
    }