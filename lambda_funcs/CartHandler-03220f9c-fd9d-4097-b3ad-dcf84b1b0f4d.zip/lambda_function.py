import json
import boto3
from decimal import Decimal

dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table('Cart')

def get_cart(session_id):
    try:
        response = table.get_item(Key={'session_id': session_id})
        return response.get('Item', {'session_id': session_id, 'items': []})
    except Exception as e:
        print(f"Error fetching cart: {e}")
        return {'session_id': session_id, 'items': []}

# Convert decimal to int or float
def convert_decimals(obj):
    if isinstance(obj, list):
        return [convert_decimals(i) for i in obj]
    elif isinstance(obj, dict):
        return {k: convert_decimals(v) for k, v in obj.items()}
    elif isinstance(obj, Decimal):
        return int(obj) if obj % 1 == 0 else float(obj)
    else:
        return obj


# Reformat the dynamodb data for easy appliance to frontend
def reformat_cart_items(items):
    formatted = []
    for i in items:
        formatted.append({
            "id": i["item"]["name"],
            "name": i["item"]["name"],
            "price": i["item"]["price"],
            "qty": i["quantity"],
            "image_url": i["item"].get("image_url")
        })
    return formatted


def lambda_handler(event, context):
    try:
        body = json.loads(event["body"])
        session_id = body.get("sessionId")

        if not session_id:
            return {
                'statusCode': 400,
                'body': json.dumps({'error': 'sessionId is required'})
            }

        # Fetch cart from DynamoDB
        cart = get_cart(session_id)

        raw_items = cart.get("items", [])
        raw_items = convert_decimals(raw_items)
        items = reformat_cart_items(raw_items)

        return {
            "statusCode": 200,
            "headers": {
                "Content-Type": "application/json",
                "Access-Control-Allow-Origin": '*'
            },
            "body": json.dumps({
                "items": items
            })
        }

    except Exception as e:
        print(f"Lambda error: {e}")
        return {
            "statusCode": 500,
            "body": json.dumps({"error": "Internal server error"})
        }