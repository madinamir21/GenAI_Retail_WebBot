import { LexRuntimeV2Client, RecognizeTextCommand } from "@aws-sdk/client-lex-runtime-v2";
import { LambdaClient, InvokeCommand } from "@aws-sdk/client-lambda";

const lexClient    = new LexRuntimeV2Client({ region: "us-east-1" });
const lambdaClient = new LambdaClient({ region: "us-east-1" });

export const handler = async (event) => {
  try {
    const body = JSON.parse(event.body);
    const { message, sessionId, localeId } = body;

    const command = new RecognizeTextCommand({
      botId: "CZQPNYRSG6",
      botAliasId: "GIG542XM07",
      localeId: localeId,
      sessionId: sessionId,
      text: message,
    });

    const response = await lexClient.send(command);
    console.log("Full Lex response:", JSON.stringify(response, null, 2));

    const botReply   = response.messages?.map(msg => msg.content) || ["Sorry, I didn't get that."];
    const intentName = response.sessionState?.intent?.name;
    const sessionAttrs = response.sessionState?.sessionAttributes || {};

    //Forward mapRoute from session attributes
    if (sessionAttrs.mapRoute) {
      try {
        const mapRoute = JSON.parse(sessionAttrs.mapRoute);
        return {
          statusCode: 200,
          headers: { "Access-Control-Allow-Origin": "*" },
          body: JSON.stringify({ messages: botReply, mapRoute }),
        };
      } catch (_) {}
    }

    // Forward mapLocation
    if (sessionAttrs.mapLocation) {
      try {
        const mapLocation = JSON.parse(sessionAttrs.mapLocation);
        return {
          statusCode: 200,
          headers: { "Access-Control-Allow-Origin": "*" },
          body: JSON.stringify({ messages: botReply, mapLocation }),
        };
      } catch (_) {}
    }

    // Default
    return {
      statusCode: 200,
      headers: { "Access-Control-Allow-Origin": "*" },
      body: JSON.stringify({ messages: botReply }),
    };

  } catch (error) {
    console.error("Lex error:", error);
    return {
      statusCode: 500,
      body: JSON.stringify({ messages: "Oops, something went wrong with Lex." }),
    };
  }
};
