# Filename: lambda_function.py
# Author: Gen AI Retail 
# Description:
#    This program handles lambda function based on lex intents from the AI chatbot
#    It does the respective action for each lex intent connected to lambda function


import json
import boto3
import csv
import io
import difflib
from decimal import Decimal
import subprocess
import sys
#subprocess.call([sys.executable, "-m", "pip", "install", "rapidfuzz", "-t", "/tmp/"])
#sys.path.insert(0, "/tmp/")

#from rapidfuzz import process, fuzz 

s3=boto3.client('s3')
BUCKET = 'genairetail'
dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table('Cart')

region = 'us-east-1'
bedrock = boto3.client('bedrock-runtime', region_name=region)
bedrock_agent = boto3.client('bedrock-agent-runtime', region_name=region)
CLAUDE_MODEL = 'us.anthropic.claude-sonnet-4-20250514-v1:0'

# Handler function parses intent for respective actions
def lambda_handler(event, context):
    intent_name = event['sessionState']['intent']['name']
    session_attrs = event['sessionState'].get('sessionAttributes', {})

    if session_attrs.get('pendingItem'):
        return addToCart(event)


    if intent_name == 'addToCart':
        return addToCart(event)

    if intent_name == 'removeItem':
        return removeFromCart(event)
    
    if intent_name == 'viewCart':
        return viewCart(event)

    if intent_name == 'QnA':
        return QnAClaude(event)

    if intent_name == 'QnAImage':
        return QnAImage(event)

    if intent_name == 'FallbackIntent':
        return fallback(event)
    
    
    
# add to cart intent function, adds users requested item to cart
def addToCart(event):
    session_attrs = event['sessionState'].get('sessionAttributes', {})
    pending_item = session_attrs.get('pendingItem')
    user_input = event.get('inputTranscript', '')

    if not pending_item :

        slots = event['sessionState']['intent']['slots']
        item_name = slots['ProductName']['value']['interpretedValue']
        quantity = int(slots.get('Number', {}).get('value', {}).get('interpretedValue', 1))

        raw_session_id = event['sessionId']
        if '-' in raw_session_id:
            session_id = raw_session_id.rsplit('-', 1)[0]
        else:
            session_id = raw_session_id

        item = get_item_from_s3(item_name)

        if not item:
            return lex_response(event, f"Sorry I could not find {item_name} in our database")

        session_attrs['pendingItem'] = json.dumps(item)
        session_attrs['pendingQuantity'] = str(quantity)

        return lex_response_with_attrs(event, f"I found {item['name']} for ${item['price']}. Is that what you wanted?", session_attrs)


    else:
        print(f"In else block, user_input: '{user_input}'")
        print(f"pending_item: '{pending_item}'")


        item = json.loads(session_attrs.get('pendingItem'))
        quantity = int(session_attrs.get('pendingQuantity', 1))
        raw_session_id = event['sessionId']
        if '-' in raw_session_id:
            session_id = raw_session_id.rsplit('-', 1)[0]
        else:
            session_id = raw_session_id
        
        system_prompt = f"""
            Deduct if the users respone is saying yes or no, respond only with 'yes' if the user is saying yes, and 'no' if they are suggesting no
        """

        body = {
            "anthropic_version": "bedrock-2023-05-31",
            "max_tokens": 800,
            "temperature": 0.2,
            "system": system_prompt,
            "messages": [
                {"role": "user", "content": f"{user_input}"}
            ]
        }

        response = bedrock.invoke_model(
           modelId=CLAUDE_MODEL,
            body=json.dumps(body)
        )

        result = json.loads(response["body"].read())
        answer = result["content"][0]["text"]

        print(f"Yes/no answer: '{answer}'")



        if answer == 'yes':

            quantity_prompt = f"If the user requested a specific quantity in this message: '{user_input}'? return ONLY the numerical integer of the number they requested,If no number is mentioned return 1. Examples: 'yes can i have 2' -> 2, 'yes please' -> 1, 'yeah get me 3' -> 3"

            body = {
                "anthropic_version": "bedrock-2023-05-31",
                "max_tokens": 800,
                "temperature": 0.2,
                "messages": [
                    {"role": "user", "content": f"{quantity_prompt}"}
                ]
            }
            quanity_response = bedrock.invoke_model(
                modelId=CLAUDE_MODEL,
                body=json.dumps(body)
            )

            quantity_result = json.loads(quanity_response["body"].read())
            requested_quantity = quantity_result["content"][0]["text"].strip()

            print(f"Quantity extraction input: '{user_input}'")
            print(f"Bot Response: '{quantity_result}'")
            print(f"Requested quantity: '{requested_quantity}'")

            if int(requested_quantity) > 1:
                try:
                    quantity = int(requested_quantity)
                except:
                    quantity = int(session_attrs.get('pendingQuantity', 1))

            cart = get_cart(session_id)

            item_exists = False

            for cart_item in cart['items']:
                if cart_item['item']['name'] == item['name']:
                    cart_item['quantity'] += quantity
                    item_exists = True
                break

            if not item_exists:

                cart['items'].append({
                    'item': {
                        'name': item['name'], 
                        'price': Decimal(str(item['price'])),
                        'image_url': item['image_url']
                    }, 
                    'quantity': quantity
                })

            save_cart(session_id, cart)
            
            session_attrs.pop('pendingItem')
            session_attrs.pop('pendingQuantity')
    
            return lex_response_with_attrs(event, f"Added {quantity}x {item['name']} to your cart!", session_attrs)
        
        elif answer == 'no':
            new_item_prompt = f"""
                Deduct in this message if the user is requesting a different product or specifying their search: '{user_input}.
                If the user IS updating their search, return ONLY the segment of text describing the item they want OR the item name if the user is sepcific.
                Examples:
                "No, I want the individual banana fruit" -> "Individual banana fruit"
                "No, I want 2% milk" -> "2% milk"
                "Thats wrong, I need the organic apples" -> "organic apples"         
                            
                If the user IS NOT updating their search and the meaning of the message is "no thats not what i want" simply return "No"
            """

            body = {
                "anthropic_version": "bedrock-2023-05-31",
                "max_tokens": 800,
                "temperature": 0.2,
                "messages": [
                    {"role": "user", "content": f"{new_item_prompt}"}
                ]
            }
            new_item_response = bedrock.invoke_model(
                modelId=CLAUDE_MODEL,
                body=json.dumps(body)
            )

            new_item_response = json.loads(new_item_response["body"].read())
            new_item_text = new_item_response["content"][0]["text"]
            print(f"new item: {new_item_text}")


            if new_item_text == 'No':
                session_attrs.pop('pendingItem')
                session_attrs.pop('pendingQuantity')
                return lex_response_with_attrs(event, f"I'm sorry I did not find the right product, could you try describing it differently?", session_attrs)
            
            else:
                
                session_attrs.pop('pendingItem')
                session_attrs.pop('pendingQuantity')

                new_item = get_item_from_s3(new_item_text)

                if not new_item:
                    return lex_response(event, f"Sorry I could not find {new_item_name} in our database")

                session_attrs['pendingItem'] = json.dumps(new_item)
                session_attrs['pendingQuantity'] = str(quantity)

                return lex_response_with_attrs(event, f"Okay! Instead, I found {new_item['name']} for ${new_item['price']}. Is that what you wanted?",session_attrs)

                #event["sessionState"]["sessionAttributes"] = session_attrs
                #event["sessionState"]["intent"]["slots"]["ProductName"]["value"]["interpretedValue"] = new_item_text
                #return addToCart(event)

# remove items from cart
def removeFromCart(event):
    raw_session_id = event['sessionId']
    if '-' in raw_session_id:
        session_id = raw_session_id.rsplit('-', 1)[0]
    else:
        session_id = raw_session_id
    cart = get_cart(session_id)

    session_attrs = event['sessionState'].get('sessionAttributes', {})
    user_input = event.get('inputTranscript', '')

    if not cart['items']:
        return lex_response(event, f"Your cart is empty")

    prompt = f"""From the list of items in {cart}, return ONLY the EXACT item name of the item the user most likely would like to remove. 
                IF the users query suggests they would like to compeletly empty their cart return ONLY 'all'
                This is the users query: {user_input}
    """
    body = {
                "anthropic_version": "bedrock-2023-05-31",
                "max_tokens": 800,
                "temperature": 0.2,
                "messages": [
                    {"role": "user", "content": f"{prompt}"}
                ]
            }
    item_response = bedrock.invoke_model(
        modelId=CLAUDE_MODEL,
        body=json.dumps(body)
    )

    item_result = json.loads(item_response["body"].read())
    item_request = item_result["content"][0]["text"]

    prompt_num = f"""From this message: "{user_input}"
                Return ONLY one of these two things:
                - The integer if a specific number is mentioned. Example: "remove 2 milk" -> 2
                - The word max if no number is mentioned. Example: "remove the milk" -> max

                Do not explain. Do not add punctuation. Return only the integer or the word max."""

    body = {
                "anthropic_version": "bedrock-2023-05-31",
                "max_tokens": 800,
                "temperature": 0.2,
                "messages": [
                    {"role": "user", "content": f"{prompt_num}"}
                ]
            }
    num_response = bedrock.invoke_model(
        modelId=CLAUDE_MODEL,
        body=json.dumps(body)
    )

    num_result = json.loads(num_response["body"].read())
    num_request= num_result["content"][0]["text"]

    if item_request == 'all':
        empty_cart = {'session_id': session_id, 'items': []}
        save_cart(session_id, empty_cart)
        return lex_response_with_attrs(event, "Your cart has been cleared!", session_attrs)

    if num_request == 'max':
        for i in cart['items']:
            if i['item']['name'] == item_request:
                cart['items'].remove(i)
                break

        save_cart(session_id, cart)
        return lex_response_with_attrs(event, f"Removed {item_request} from your cart!", session_attrs)

    else:
        for i in cart['items']:
            if i['item']['name'] == item_request:
                i['quantity'] -= int(num_request)
                if i['quantity'] <= 0:
                    cart['items'].remove(i)
                break
        
        save_cart(session_id, cart)
        return lex_response_with_attrs(event, f"Removed x{num_request} {item_request} from your cart!", session_attrs)



    

# view to cart intent function, prints out the users cart
def viewCart(event):
    raw_session_id = event['sessionId']
    if '-' in raw_session_id:
        session_id = raw_session_id.rsplit('-', 1)[0]
    else:
        session_id = raw_session_id
    cart = get_cart(session_id)
    total = 0
    if not cart['items']:
        return lex_response(event, f"Your cart is empty")

    cart_list = " | ".join([f"x{i['quantity']} {i['item']['name']}" for i in cart['items']])

    for i in cart['items']:
        total += i['quantity'] * i['item']['price']

    return lex_response(event, f"Here is your cart: {cart_list} Total cost: {total:.2f}")

    # format i want
    # Here is your cart:
    # x2 Bananas
    # x3 oranges
    # x1 Whole Milk
    # Total: $10.25

# get items from s3, searches for s3 items and returns data about specific item
def get_item_from_s3(item_name):
    try: 
        response = s3.get_object(Bucket=BUCKET, Key='database_no_ingredients.csv')
        content = response['Body'].read().decode('utf-8')
        reader = csv.DictReader(io.StringIO(content))
        rows = list(reader)

        #bestMatch = findBestMatch(item_name, rows)
        bestMatch = searchKnowledgeBase(item_name)
        if not bestMatch:
            return None

        for row in rows:
            if row['product_name'] == bestMatch:
                return{
                    'name': row['product_name'],
                    'price': float(row['price']) if row['price'] else None,
                    'image_url': row['image_url'] if row['image_url'] else None,
                    ##'quantity': int(row['quantity']) if row['quantity'] else None,
                }
        return None
    
    except Exception as e:
        print(f"Error fetching item from S3: {e}")
        return None

# OLDEST find best match, string matches best match from  csv database
def findBestMatch_old(item_name, rows):  ## keeping this function for future functions like remove from cart
    names = [row['product_name'] for row in rows]
    matches = difflib.get_close_matches(item_name, names, n=1, cutoff = 0.6)
    return matches[0] if matches else None

# OLD find best match, finds best match from csv database based on user search items
def findBestMatch(item_name, rows):
    names = [row['product_name'] for row in rows]
   
    results = process.extract(item_name, names, scorer=fuzz.token_sort_ratio, limit = 3)
    print(results)

    if not results:
        return None

    best_match, score, index = results[0]  

    if score < 0:  
        return None

    return best_match

# search bedrock knowledge base, new 'find best match'
def searchKnowledgeBase(item_name):
    lookup = bedrock_agent.retrieve(
        knowledgeBaseId='0UUJSNAL69',
        retrievalQuery={
            'text': item_name
        },
        retrievalConfiguration={
            'vectorSearchConfiguration': {
                'numberOfResults': 10
            }
        }
    )

    returned_item = "\n".join([r['content']['text'] for r in lookup['retrievalResults']]) if lookup['retrievalResults'] else ' '

    
    system_prompt = f"""
        You are a product matching  assistant.
        help match the item name: {item_name} to the best product name from the provide knowledge base search response: {returned_item}
        
        Find the product name that BEST matches what the customer searched for.
        The customer might describe a product instead of naming it exactly.
        Examples: 
        - "orange fruit by itself" -> "Oranges"
        - "something for breakfast cereal" -> "Oatmeal" or "Granola"
        Return ONLY the exact product name as it appears in the text, nothing else.
        Do not return ingredients, do not return partial matches.
    """

    body = {
        "anthropic_version": "bedrock-2023-05-31",
        "max_tokens": 800,
        "temperature": 0.2,
        "system": system_prompt,
        "messages": [
            {"role": "user", "content": f"Find the best match for: {item_name}"}
        ]
    }

    response = bedrock.invoke_model(
        modelId=CLAUDE_MODEL,
        body=json.dumps(body)
    )

    result = json.loads(response["body"].read())
    answer = result["content"][0]["text"]

    #print(f"KB returned text: '{returned_item}'")
    #print(f"KB Search for '{item_name}' returned: '{answer}'")
    
    return answer

# get cart, gets cart from dynamoDB table
def get_cart(session_id):
    try:
        response = table.get_item(Key={'session_id' : session_id})
        return response.get('Item', {'session_id': session_id, 'items' : []})
    except Exception as e:
        print(f"Error fetching cart: {e}")
        return {'session_id': session_id, 'items': []}
    
# save cart, adds item to cart and saves it
def save_cart(session_id, cart):
    try:
        table.put_item(Item=cart)
    except Exception as e:
        print(f"Error saving cart: {e}")

# QnA,  queries claude about user question
def QnAClaude(event):
    session_attrs = event['sessionState'].get('sessionAttributes', {})
    if session_attrs.get('pendingItem'):
        return addToCart(event)

    user_input = event.get('inputTranscript', '')
    
    system_prompt = """
        You are a retail assistant.
        Answer the user question clearly and precisely
    """

    body = {
        "anthropic_version": "bedrock-2023-05-31",
        "max_tokens": 800,
        "temperature": 0.2,
        "system": system_prompt,
        "messages": [
            {
                "role": "user",
                "content": f"Question:\n{user_input}"
                
            }
        ]
    }

    response = bedrock.invoke_model(
        modelId=CLAUDE_MODEL,
        body=json.dumps(body)
    )

    result = json.loads(response["body"].read())
    answer = result["content"][0]["text"]

    return lex_response(event, answer)

# get items from s3, searches for s3 image url and returns the image url about specific item
def get_imageurl_from_s3(item_name):
    try: 
        response = s3.get_object(Bucket=BUCKET, Key='database_no_ingredients.csv')
        content = response['Body'].read().decode('utf-8')
        reader = csv.DictReader(io.StringIO(content))
        rows = list(reader)

        #bestMatch = findBestMatch(item_name, rows)
        bestMatch = searchKnowledgeBase(item_name)
        if not bestMatch:
            return None

        for row in rows:
            if row['product_name'] == bestMatch:
                return{
                    'name': row['product_name'],
                    'image_url': row['image_url'] if row['image_url'] else None,
                }
        return None
    
    except Exception as e:
        print(f"Error fetching item from S3: {e}")
        return None

# Find image url of product and return the product name and image url
def QnAImage(event):
    session_attrs = event['sessionState'].get('sessionAttributes', {})
    if session_attrs.get('pendingItem'):
        return addToCart(event)

    slots = event['sessionState']['intent']['slots']
    item_name = slots['Product']['value']['interpretedValue']

    item = get_imageurl_from_s3(item_name)

    if item and item.get('image_url'):
        message = f"Here is an image of {item['name']}: {item['image_url']}"
    else:
        message = f"Sorry, I don't have an image for {item_name}."

    return lex_response(event, message)

def fallback(event):
    raw_session_id = event['sessionId']
    if '-' in raw_session_id:
        session_id = raw_session_id.rsplit('-', 1)[0]
    else:
        session_id = raw_session_id
    session_attrs = event['sessionState'].get('sessionAttributes', {})
    cart = get_cart(session_id)
    message = event.get('inputTranscript', '')
    session_attrs = event['sessionState'].get('sessionAttributes', {})
    history = json.loads(session_attrs.get('conversationHistory', '[]'))
    cart_contents = ", ".join([i['item']['name'] for i in cart['items']]) if cart['items'] else "empty"


    system_prompt = f"""You are a friendly grocery shopping assistant. 
    Current cart: {cart_contents}
    Be conversational and keep responses concise. Dont mention products that are not in the grocery database"""

    body = {
        "anthropic_version": "bedrock-2023-05-31",
        "max_tokens": 800,
        "temperature": 0.2,
        "system": system_prompt,
        "messages":  history + [{ "role": "user", "content": message }]
        }

    
    response = bedrock.invoke_model(
        modelId=CLAUDE_MODEL,
        body=json.dumps(body)
    )

    result = json.loads(response["body"].read())
    answer = result["content"][0]["text"]
    history.append({'role': 'user', 'content': message})
    history.append({'role': 'assistant', 'content': answer})
    session_attrs['conversationHistory'] = json.dumps(history)


    return lex_response_with_attrs(event, answer, session_attrs)


    

# lex response, formating for lex to give a response to user
def lex_response(event, message):
    return {
        "sessionState": {
            "dialogAction": {"type": "Close"},
            "intent": {
                "name": event['sessionState']['intent']['name'],
                "state": "Fulfilled"
            }
        },
        "messages": [{"contentType": "PlainText", "content": message}]
    }


def lex_response_with_attrs(event, message, session_attrs):
    return {
        "sessionState": {
            "dialogAction": {"type": "Close"},
            "intent": {
                "name": event['sessionState']['intent']['name'],
                "state": "Fulfilled"
            },
            "sessionAttributes": session_attrs
        },
        "messages": [{"contentType": "PlainText", "content": message}]
    }